//Author: Jack Handy
//Date: 3/23/2021

import java.awt.event.MouseEvent;

public interface Mover {

	void mousePressed(MouseEvent e);
	void mouseDragged(MouseEvent e);
}
